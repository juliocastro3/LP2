﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtladoA.Clear();
            txtladoB.Clear();
            txtladoC.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                Double ladoA = 0, ladoB = 0, ladoC = 0;

                ladoA = Double.Parse(txtladoA.Text);
                ladoB = Double.Parse(txtladoB.Text);
                ladoC = Double.Parse(txtladoC.Text);


                if (ladoA > 0 && ladoB > 0 && ladoC > 0)
		{
                    if (Math.Abs(ladoB - ladoC) < ladoA && ladoA < (ladoB + ladoC) && 
                        Math.Abs(ladoA - ladoC) < ladoB && ladoB < (ladoA + ladoC) &&
                        Math.Abs(ladoA - ladoB) < ladoC && ladoC < (ladoA + ladoB))
                    {
                        if ((ladoA == ladoB) && (ladoA == ladoC))
                        {
                            MessageBox.Show("Triângulo Equilatero");
                        }

                        else if ((ladoA == ladoB) && (ladoA != ladoC) || (ladoA != ladoB) && (ladoA == ladoC) || (ladoB == ladoC) && (ladoB != ladoA))
                        {
                            MessageBox.Show("Triângulo Isosceles");
                        }

                        else if ((ladoA != ladoB) && (ladoA != ladoC) && (ladoB != ladoC))
                        {
                            MessageBox.Show("Triângulo Escaleno");
                        }
                    }

                    else
                        MessageBox.Show("Não contempla a condição de existência de um triângulo!");
                }


        else
                    MessageBox.Show("Lados não podem ser zero!");
            




            }

            catch (Exception)
            {

                MessageBox.Show("Dados Invalidos");
            }
            }
        internal class Dooble
        {
        }

        private void txtladoA_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtladoA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsPunctuation(e.KeyChar) && e.KeyChar != (char)Keys.Enter &&
                e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)

                e.Handled = true;
        }

        private void txtladoB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsPunctuation(e.KeyChar) && e.KeyChar != (char)Keys.Enter &&
                e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)

                e.Handled = true;
        }

        private void txtladoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsPunctuation(e.KeyChar) && e.KeyChar != (char)Keys.Enter &&
                e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)

                e.Handled = true;
        }
    }
}

