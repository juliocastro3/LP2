﻿
namespace Pmetodos
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtTexto = new System.Windows.Forms.RichTextBox();
            this.btnTotalCaracter = new System.Windows.Forms.Button();
            this.btnCaracterBranco = new System.Windows.Forms.Button();
            this.btnCaracteresAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtTexto
            // 
            this.rtTexto.Location = new System.Drawing.Point(12, 12);
            this.rtTexto.Name = "rtTexto";
            this.rtTexto.Size = new System.Drawing.Size(378, 175);
            this.rtTexto.TabIndex = 0;
            this.rtTexto.Text = "";
            // 
            // btnTotalCaracter
            // 
            this.btnTotalCaracter.Location = new System.Drawing.Point(12, 273);
            this.btnTotalCaracter.Name = "btnTotalCaracter";
            this.btnTotalCaracter.Size = new System.Drawing.Size(101, 42);
            this.btnTotalCaracter.TabIndex = 1;
            this.btnTotalCaracter.Text = "Total Caracteres Numericos";
            this.btnTotalCaracter.UseVisualStyleBackColor = true;
            this.btnTotalCaracter.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCaracterBranco
            // 
            this.btnCaracterBranco.Location = new System.Drawing.Point(150, 273);
            this.btnCaracterBranco.Name = "btnCaracterBranco";
            this.btnCaracterBranco.Size = new System.Drawing.Size(112, 42);
            this.btnCaracterBranco.TabIndex = 2;
            this.btnCaracterBranco.Text = "Primeiro Caracter Branco + Posição";
            this.btnCaracterBranco.UseVisualStyleBackColor = true;
            this.btnCaracterBranco.Click += new System.EventHandler(this.btnCaracterBranco_Click);
            // 
            // btnCaracteresAlfabeticos
            // 
            this.btnCaracteresAlfabeticos.Location = new System.Drawing.Point(292, 273);
            this.btnCaracteresAlfabeticos.Name = "btnCaracteresAlfabeticos";
            this.btnCaracteresAlfabeticos.Size = new System.Drawing.Size(98, 42);
            this.btnCaracteresAlfabeticos.TabIndex = 3;
            this.btnCaracteresAlfabeticos.Text = "Total Caracteres Alfabeticos";
            this.btnCaracteresAlfabeticos.UseVisualStyleBackColor = true;
            this.btnCaracteresAlfabeticos.Click += new System.EventHandler(this.btnCaracteresAlfabeticos_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCaracteresAlfabeticos);
            this.Controls.Add(this.btnCaracterBranco);
            this.Controls.Add(this.btnTotalCaracter);
            this.Controls.Add(this.rtTexto);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtTexto;
        private System.Windows.Forms.Button btnTotalCaracter;
        private System.Windows.Forms.Button btnCaracterBranco;
        private System.Windows.Forms.Button btnCaracteresAlfabeticos;
    }
}