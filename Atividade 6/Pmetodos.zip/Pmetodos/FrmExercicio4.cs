﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            for(int caracter = 0; caracter < rtTexto.Text.Length; caracter++)
            {
                if(char.IsDigit(rtTexto.Text[caracter]))
                {
                    quantidade++;
                }
            }

                MessageBox.Show(quantidade.ToString());
        }

        private void btnCaracteresAlfabeticos_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            foreach (char letra in rtTexto.Text)
            {
                if (char.IsLetter(letra))
                {
                    quantidade++;
                }
            }



            MessageBox.Show(quantidade.ToString());
        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            if(rtTexto.TextLength >0)

                 while ( !char.IsWhiteSpace(rtTexto.Text[posicao]))
                {

                    if ( posicao == rtTexto.TextLength -1)
                    {
                        break;
                    }

                       posicao++;
                }



            MessageBox.Show(posicao.ToString());
        }
    }
}
