﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Peso_Ideal_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Double altura = 0, pesoideal = 0, peso_atual = 0;

                altura = Double.Parse(txtaltura.Text);


                peso_atual = double.Parse(txtpeso_atual.Text);

                if (cmbsexo.Text == "Mulher")
                {
                    pesoideal = (62.1 * altura) - 44.7;
                    MessageBox.Show("Seu Peso Ideal é: " + pesoideal.ToString("0.00") + "KG", "Peso Ideal");
                }

                else if (cmbsexo.Text == "Homem")

                {
                    pesoideal = (72.7 * altura) - 58;
                    MessageBox.Show("Seu Peso Ideal é: " + pesoideal.ToString("0.00") + "KG", "Peso Ideal");
                }

                {
                    if(cmbsexo.SelectedIndex == -1)
                    {
                        MessageBox.Show("Informe o sexo");
                        return;
                    }
                   
                    {
                        if (pesoideal < peso_atual)
                        {
                            MessageBox.Show("Regime Obrigatório Já");
                        }

                        else if (pesoideal > peso_atual)
                        {
                            MessageBox.Show("Coma bastante massas e doces");
                        }
                        else
                        {
                            MessageBox.Show(" Voçê esta com o Peso Ideal");
                        }
                    }
                }
            }

            catch (Exception)
            {

                MessageBox.Show("Verifique os Valores Informados", "Peso Ideal");
            }


        }



        private void button2_Click(object sender, EventArgs e)
        {
            txtaltura.Clear();
            txtpeso_atual.Clear();
           
        }

        private void cmbsexo_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void txtaltura_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtaltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsPunctuation(e.KeyChar) && e.KeyChar != (char)Keys.Enter &&
                e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)

                e.Handled = true;
        }

        private void txtpeso_atual_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsPunctuation(e.KeyChar) && e.KeyChar != (char)Keys.Enter &&
                e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)

                e.Handled = true;
        }
    }
}
