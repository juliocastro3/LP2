﻿
namespace PAtividade8
{
    partial class Frm5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExerc5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExerc5
            // 
            this.btnExerc5.Location = new System.Drawing.Point(300, 319);
            this.btnExerc5.Name = "btnExerc5";
            this.btnExerc5.Size = new System.Drawing.Size(175, 74);
            this.btnExerc5.TabIndex = 0;
            this.btnExerc5.Text = "Exercício 5";
            this.btnExerc5.UseVisualStyleBackColor = true;
            this.btnExerc5.Click += new System.EventHandler(this.btnExerc5_Click);
            // 
            // Frm5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExerc5);
            this.Name = "Frm5";
            this.Text = "Frm5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExerc5;
    }
}