﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Frm1 : Form
    {
        public Frm1()
        {
            InitializeComponent();
        }

        private void Frm1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com o número da posição:"+ (i+1).ToString(), "Entrada de Dados");
                
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Invalido!");
                    i--;
                }
              
            }
            auxiliar = "";
            
            for (var i = vetor.Length - 1; i >= 0; i--)
            {
                auxiliar += vetor[i] + "\n";
            }

            MessageBox.Show(auxiliar);
        }
    }
}
