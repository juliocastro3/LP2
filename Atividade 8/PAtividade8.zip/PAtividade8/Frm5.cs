﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class Frm5 : Form
    {
        public Frm5()
        {
            InitializeComponent();
        }

        private void btnExerc5_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList(new string[] { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" });
            string saida = "";
            
            alunos.Remove("Otávio");

            saida = "";
            foreach (string s in alunos)
                saida += s.ToString() + "\n";
            MessageBox.Show("\n" + saida);
        }
    }
}
