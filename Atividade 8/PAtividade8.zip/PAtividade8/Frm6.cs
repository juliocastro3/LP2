﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class Frm6 : Form
    {
        public Frm6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] medias = new double[20];
            string saida = "";

            for ( int aluno = 0; aluno < 20; aluno++)
            {
                for ( int nota = 0; nota < 3; nota++ )
                {
                    var leitura = Interaction.InputBox($"Nota {nota + 1}", $"Notas Aluno {aluno + 1}");

                    if(!double.TryParse(leitura, out notas[aluno,nota]))
                    {
                        MessageBox.Show("Erro, Coloque um Valor Válido");
                        nota--;
                        continue;
                    }

                    medias[aluno] += notas[aluno, nota];
                }

                medias[aluno] /= 3.0;
                saida += $" Aluno {aluno + 1}: Média: {medias[aluno]:N2}  \n";
            }

            MessageBox.Show(saida);
        }
    }
}
