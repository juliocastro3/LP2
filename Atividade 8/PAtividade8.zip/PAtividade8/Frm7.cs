﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Frm7 : Form
    {
        public Frm7()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[6];
            int[] Letras = new int[nomes.Length];

            for (int i = 0; i < nomes.Length; i++)
            {
                var leitura = Interaction.InputBox($"Entre com o {i+1} nome", "Leitura de Nomes");

                if (string.IsNullOrEmpty(leitura))
                {
                    MessageBox.Show("Nome Inválido");
                    i--;
                    continue;
                }

                nomes[i] = leitura;
                int quantidade = 0;

                foreach (char letra in nomes[i])
                {
                    if (letra != ' ')
                        quantidade++;

                }
                
                Letras[i] = quantidade;

            }
                for ( int i = 0; i < nomes.Length; i++)
                {
                listNomes.Items.Add( $"O nome: {nomes[i]} tem {Letras[i]} caracteres \n");
                }
            }

        }
    }

