﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030482023036
{
    public partial class FrmFaturamento : Form
    {
        public FrmFaturamento()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[6, 4];
            double totSemanas, totMeses = 0;
            int mes, semana;
            string leitura;


            for (mes = 0; mes < 6; mes++)
            {

                for (semana = 0; semana < 4; semana++)
                {

                    leitura = Interaction.InputBox($"Semana {semana + 1}", $"Mês {mes + 1}");

                    if (!double.TryParse(leitura, out vendas[mes, semana]))
                    {
                        MessageBox.Show("Por favor, Insira dados Válidos.");
                        semana--;
                    }
                }
            }


            for (mes = 0; mes < 6; mes++)
            {
                totSemanas = 0;

                for (semana = 0; semana < 4; semana++)
                {
                    listFaturamento.Items.Add($"Total do mês: {mes + 1} Semana: {semana + 1}: {vendas[mes, semana]:C2}");
                    totSemanas += vendas[mes, semana];
                }

                listFaturamento.Items.Add($">> Total Mês: {totSemanas:C2}");
                totMeses += totSemanas;
                listFaturamento.Items.Add("----------------------------");
            }

            listFaturamento.Items.Add($">> Total Geral: {totMeses:C2}");
        }
    }

}

   