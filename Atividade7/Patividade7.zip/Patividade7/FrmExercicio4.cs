﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void FrmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, produção, gratificação;

            if (txtSalario.Text == "" || txtProdução.Text == "" || txtNome.Text == "" || txtInscrição.Text == "" || txtGratificação.Text == "" || txtCargo.Text == "")
                MessageBox.Show("Preencha os Dados");
            else if (double.TryParse(txtSalario.Text, out a) &&
                    double.TryParse(txtProdução.Text, out produção) &&
                    double.TryParse(txtGratificação.Text, out gratificação))
            {
                double sal, b = 0, c = 0, d = 0;

                if (produção >= 150)
                    d = 1;
                if (produção >= 120)
                    c = 1;
                if (produção >= 100)
                    b = 1;

                sal = a + a * (0.05 * b + 0.1 * c + 0.1 * d) + gratificação;

                if (sal > 7000)
                {
                    if (d == 1 && gratificação > 0)
                        txtSalarioBruto.Text = "R$ " + sal.ToString("N2");
                    else
                        MessageBox.Show("Informe os Dados Corretamentes");
                }
                else
                    txtSalarioBruto.Text = "R$ " + sal.ToString("N2");
            }
            else
                MessageBox.Show("Dados Inválidos");
        }

        private void txtProdução_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((Char.IsLetter(e.KeyChar)) || (Char.IsWhiteSpace(e.KeyChar)))
                e.Handled = true;
        }

        private void txtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((Char.IsLetter(e.KeyChar)) || (Char.IsWhiteSpace(e.KeyChar)))
                e.Handled = true;
        }

        private void txtGratificação_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtGratificação_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((Char.IsLetter(e.KeyChar)) || (Char.IsWhiteSpace(e.KeyChar)))
                e.Handled = true;
        }
    }
}
