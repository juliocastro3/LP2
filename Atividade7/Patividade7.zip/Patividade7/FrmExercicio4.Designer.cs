﻿
namespace Patividade7
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblNumeroInscrição = new System.Windows.Forms.Label();
            this.lblProdução = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblGratificação = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.txtInscrição = new System.Windows.Forms.TextBox();
            this.txtProdução = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtGratificação = new System.Windows.Forms.TextBox();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(40, 49);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(48, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome:";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(40, 91);
            this.lblCargo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(48, 16);
            this.lblCargo.TabIndex = 1;
            this.lblCargo.Text = "Cargo:";
            this.lblCargo.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblNumeroInscrição
            // 
            this.lblNumeroInscrição.AutoSize = true;
            this.lblNumeroInscrição.Location = new System.Drawing.Point(40, 133);
            this.lblNumeroInscrição.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumeroInscrição.Name = "lblNumeroInscrição";
            this.lblNumeroInscrição.Size = new System.Drawing.Size(99, 16);
            this.lblNumeroInscrição.TabIndex = 2;
            this.lblNumeroInscrição.Text = "Nº de Inscrição";
            // 
            // lblProdução
            // 
            this.lblProdução.AutoSize = true;
            this.lblProdução.Location = new System.Drawing.Point(40, 180);
            this.lblProdução.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProdução.Name = "lblProdução";
            this.lblProdução.Size = new System.Drawing.Size(70, 16);
            this.lblProdução.TabIndex = 3;
            this.lblProdução.Text = "Produção:";
            this.lblProdução.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(40, 224);
            this.lblSalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(54, 16);
            this.lblSalario.TabIndex = 4;
            this.lblSalario.Text = "Salário:";
            // 
            // lblGratificação
            // 
            this.lblGratificação.AutoSize = true;
            this.lblGratificação.Location = new System.Drawing.Point(40, 274);
            this.lblGratificação.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGratificação.Name = "lblGratificação";
            this.lblGratificação.Size = new System.Drawing.Size(83, 16);
            this.lblGratificação.TabIndex = 5;
            this.lblGratificação.Text = "Gratificação:";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(40, 335);
            this.lblSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(88, 16);
            this.lblSalarioBruto.TabIndex = 6;
            this.lblSalarioBruto.Text = "Salário Bruto:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(169, 46);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(181, 22);
            this.txtNome.TabIndex = 7;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(169, 91);
            this.txtCargo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(181, 22);
            this.txtCargo.TabIndex = 8;
            // 
            // txtInscrição
            // 
            this.txtInscrição.Location = new System.Drawing.Point(169, 133);
            this.txtInscrição.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtInscrição.Name = "txtInscrição";
            this.txtInscrição.Size = new System.Drawing.Size(181, 22);
            this.txtInscrição.TabIndex = 9;
            // 
            // txtProdução
            // 
            this.txtProdução.Location = new System.Drawing.Point(169, 176);
            this.txtProdução.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtProdução.Name = "txtProdução";
            this.txtProdução.Size = new System.Drawing.Size(181, 22);
            this.txtProdução.TabIndex = 10;
            this.txtProdução.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProdução_KeyPress);
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(169, 220);
            this.txtSalario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(181, 22);
            this.txtSalario.TabIndex = 11;
            this.txtSalario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalario_KeyPress);
            // 
            // txtGratificação
            // 
            this.txtGratificação.Location = new System.Drawing.Point(169, 266);
            this.txtGratificação.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtGratificação.Name = "txtGratificação";
            this.txtGratificação.Size = new System.Drawing.Size(181, 22);
            this.txtGratificação.TabIndex = 12;
            this.txtGratificação.TextChanged += new System.EventHandler(this.txtGratificação_TextChanged);
            this.txtGratificação.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGratificação_KeyPress);
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(169, 332);
            this.txtSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.ReadOnly = true;
            this.txtSalarioBruto.Size = new System.Drawing.Size(181, 22);
            this.txtSalarioBruto.TabIndex = 13;
            this.txtSalarioBruto.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(131, 401);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(129, 51);
            this.btnCalcular.TabIndex = 14;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.txtGratificação);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtProdução);
            this.Controls.Add(this.txtInscrição);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblGratificação);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblProdução);
            this.Controls.Add(this.lblNumeroInscrição);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.lblNome);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.Load += new System.EventHandler(this.FrmExercicio4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblNumeroInscrição;
        private System.Windows.Forms.Label lblProdução;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblGratificação;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.TextBox txtInscrição;
        private System.Windows.Forms.TextBox txtProdução;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtGratificação;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.Button btnCalcular;
    }
}