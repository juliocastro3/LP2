﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void lblNumero_Click(object sender, EventArgs e)
        {

        }

        private void btnGeradorH_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNumero.Text, out double n))
            {
                if (n > 0)
                {
                    double h = 0;
                    for (double i = 1; i <= n; i++)
                        h += 1 / i;
                    txtNumeroH.Text = h.ToString("N3");
                }
                else
                    MessageBox.Show("Deve ser maior que 0");
            }
            else if (txtNumero.Text == "")
                MessageBox.Show("Informe um Número");
            else
                MessageBox.Show("Dado Inválido");
        }

        private void txtNumeroH_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

