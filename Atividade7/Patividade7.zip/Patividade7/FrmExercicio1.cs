﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaçoembranco_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Digite um Texto");
            else if (rtxtTexto.TextLength > 100)
                MessageBox.Show("Texto maior que o permitido");
            else
            {
                char[] texto = rtxtTexto.Text.ToCharArray();
                int contador = 0;

                for (int i = 0; i < texto.Length; i++)
                {
                    if (char.IsWhiteSpace(texto[i]))
                        contador += 1;
                }
                MessageBox.Show(Convert.ToString(contador) + " espaço(s) em branco");
            }
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Digite um Texto");
            else if (rtxtTexto.TextLength > 100)
                MessageBox.Show("Texto maior que o permitido");
            else
            {
                char[] texto = rtxtTexto.Text.ToCharArray();
                int cont = 0, i = 0;

                while (i < texto.Length)
                {
                    if (char.Equals(texto[i], 'R'))
                        cont += 1;
                    i++;
                }
                MessageBox.Show(Convert.ToString(cont) + " letra(s) 'R'");
            }
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Digite um Texto");
            else if (rtxtTexto.TextLength > 100)
                MessageBox.Show("Texto maior que o permitido");
            else
            {
                char[] texto = rtxtTexto.Text.ToCharArray();
                int cont = 0, i = 1;

                while (i < texto.Length)
                {
                    if (char.Equals(texto[i], texto[i - 1]))
                        cont += 1;
                    i++;
                }
                MessageBox.Show(Convert.ToString(cont) + " par(es)");
            }
        }

    }
    
}
